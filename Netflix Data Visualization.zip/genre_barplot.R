
# genre_barplot.R
# This script reads the cleaned Netflix dataset and generates a Top Genres bar chart using ggplot2.
# Output: most_watched_genres_R.png

# Usage:
#   install.packages(c("readr", "dplyr", "tidyr", "ggplot2"))
#   setwd("/mnt/data/netflix_assignment")
#   source("genre_barplot.R")

library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)

data_path <- file.path("/mnt/data/netflix_assignment", "Netflix_shows_movies_cleaned.csv")
df <- read_csv(data_path, show_col_types = FALSE)

if (!"listed_in" %in% names(df)) {{
  stop("Column 'listed_in' not found in dataset.")
}}

# Split genres and count
genres <- df %>%
  mutate(listed_in = ifelse(is.na(listed_in), "Unknown", listed_in)) %>%
  separate_rows(listed_in, sep = ",") %>%
  mutate(listed_in = trimws(listed_in)) %>%
  filter(listed_in != "") %>%
  count(listed_in, name = "count") %>%
  arrange(desc(count)) %>%
  slice_head(n = 10)

p <- ggplot(genres, aes(x = reorder(listed_in, count), y = count)) +
  geom_col() +
  coord_flip() +
  labs(title = "Top Genres (Count of Titles)", x = "Genre", y = "Count") +
  theme_minimal()

ggsave(filename = "most_watched_genres_R.png", plot = p, width = 8, height = 5, dpi = 200)
