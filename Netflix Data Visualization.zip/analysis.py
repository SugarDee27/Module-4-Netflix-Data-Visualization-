
# analysis.py
# Run with: python analysis.py
# Requires: pandas, numpy, matplotlib
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

work_dir = Path("/mnt/data/netflix_assignment")
csv_path = work_dir / "Netflix_shows_movies_cleaned.csv"

df = pd.read_csv(csv_path)

# Genre counts
if "listed_in" in df.columns:
    genres = df["listed_in"].astype(str).str.get_dummies(sep=",")
    genres.columns = [g.strip() for g in genres.columns]
    genre_counts = genres.sum().sort_values(ascending=False)
    top_genres = genre_counts.head(10)
    plt.figure()
    top_genres[::-1].plot(kind="barh")
    plt.title("Top Genres (Count of Titles)")
    plt.xlabel("Count")
    plt.ylabel("Genre")
    plt.tight_layout()
    plt.savefig(work_dir / "most_watched_genres.png", dpi=200)
    plt.close()

# Rating distribution
if "rating" in df.columns:
    rating_counts = df["rating"].value_counts(dropna=False).sort_values(ascending=False)
    plt.figure()
    rating_counts.plot(kind="bar")
    plt.title("Ratings Distribution")
    plt.xlabel("Rating")
    plt.ylabel("Count")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    plt.savefig(work_dir / "ratings_distribution.png", dpi=200)
    plt.close()
